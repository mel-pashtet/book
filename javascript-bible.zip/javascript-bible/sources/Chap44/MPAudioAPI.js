/*********************************************************************
   Danny Goodman's Windows Media Player API JavaScript Library
   Copyright 2004 Danny Goodman (www.dannyg.com). All Rights Reserved.
   Excerpted from "JavaScript Bible" 5th Edition.
   
   v.2.0   Second Release
   
   An Application Programming Interface for the following
   audio playback in Internet Explorer for Windows and
   the Microsoft Windows Media Player(tm) 9.0 or later.
     
   Load this library into your HTML document with the 
   following HTML tags:
   
   <script type="text/javascript" src="MPAudioAPI.js"></script>
   
   Add the following event handler to your document's body tag:
   
      onload="initAudioAPI('playerObjectID')"
              
   ...where 'playerObjectID' is the identifier assigned to the
   id attribute of the object tag used to embed the
   player into the page. Note that the parameters are strings. 
   You can include multiple object IDs, if necessary.
   
   Your user interface controls can invoke the following API
   methods for basic audio playback control:
   
   Method             What It Does
   ---------------    -------------------------------------
   play(n)            Plays the currently loaded tune n times
   stop()             Stops the currently playing tune
   pause()            Pauses the currently playing tune
   rewind()           Rewinds the currently loaded tune to beginning
   
   load("URL")        Loads a new audio file into the player
   
   getVolume()        Returns volume integer (plug-in dependent range)
   setVolume(n)       Sets volume (n is integer from low to high range)
   
***********************************************************************/

// global variable declarations

// flag that gets set to false for incompatible browser
var OKToTest = true;

// array of player objects to control (one object per OBJECT or EMBED)
var players = new Array();

// functions invoked from AudioAPI object methods

function API_play(n) {
   if (document.all(this.id).HasError) {
      alert("MediaPlayer Alert: "  + document.all(this.id).ErrorDescription);
   } else {
      document.all(this.id).PlayCount = n;
      document.all(this.id).Play();
   }
}

function API_stop() {
   document.all(this.id).Stop();
}

function API_pause() {
   // Pause() method broken for IE5+
   document.all(this.id).Stop();
}

function API_rewind() {
   document.all(this.id).Stop();
   document.all(this.id).CurrentPosition = 0;
}

function API_load(URL) {
   document.all(this.id).Open(URL);
}

function API_getVolume() {
   return document.all(this.id).Volume;
}

function API_setVolume(n) {
   document.all(this.id).Volume = n;
}

// AudioAPI object constructor
function API(id) {
   this.id = id;
   this.play = API_play;
   this.stop = API_stop;
   this.pause = API_pause;
   this.rewind = API_rewind;
   this.load = API_load;
   this.getVolume = API_getVolume;
   this.setVolume = API_setVolume;
}

function initAudioAPI() {
   var args = initAudioAPI.arguments;
   var id;
   for (var i = 0; i < args.length; i++) {
      // don't init any more if browser lacks scriptable sound
      if (OKToTest) {
         id = args[i];
         players[id] = new API(id);
         validateSupport(id);
      }
   }
   
}

// BEGIN SUPPORT FUNCTIONS

function validateSupport(id) {
   var type = "";
   var errMsg = "This browser is not equipped for scripted sound.\n\n";
   var OS = getOS();
   var brand = getBrand();
   var ver = getVersion(brand);
   if (brand == "IE") {
      if (ver > 4) {
         if (document.all(id) && document.all(id).HasError) {
            errMsg = document.all(id).ErrorDescription;
         } else {
            if (OS == "Win") {
               if (document.all(id) && document.all(id).CreationDate != "") {
                  return "isMP";
               } else {
                  errMsg += "Expecting Windows Media Player Version 9.";
               }
            } else {
               errMsg += "Only Internet Explorer for Windows is supported.";
            }
         }
      } else { 
         errMsg += "Only Internet Explorer 4 or later for Windows is supported.";
      }
   }
   alert(errMsg);
   OKToTest = false;
   return type;
}

function getOS() {
   var ua = navigator.userAgent;
   if (ua.indexOf("Win") != -1) {
      return "Win";
   }
   if (ua.indexOf("Mac") != -1) {
      return "Mac";
   }
   return "Other";
}

function getBrand() {
   var name = navigator.appName;
   if (name == "Netscape") {
      return "NN";
   }
   if (name.indexOf("Internet Explorer") != -1) {
      return "IE";
   }
   return "Other";
}

function getVersion(brand) {
   var ver = navigator.appVersion;
   var ua = navigator.userAgent;
   if (brand == "NN") {
      if (parseInt(ver, 10) < 5) {
         return parseFloat(ver, 10);
      } else {
         return parseFloat(ua.substring(ua.lastIndexOf("/")+1));
      }
   }
   if (brand == "IE") {
      var IEOffset = ua.indexOf("MSIE ");
      return parseFloat(ua.substring(IEOffset + 5, ua.indexOf(";", IEOffset)));
   }
   return 0;
}
