/* Simple applet demonstrating access to JavaScript
   by Danny Goodman  (http://www.dannyg.com)
*/

import java.awt.*;
import java.awt.event.*;
import netscape.javascript.*;

public class JtoJSDemo extends java.applet.Applet implements ActionListener {
   private JSObject mainwin, subwin;
   private Button newWinButton, toggleButton;

   public void init() {
      setBackground(Color.white);
      newWinButton = new Button("New Browser Window");
      toggleButton = new Button("Toggle SubWindow Color");
      this.add(newWinButton);
      this.add(toggleButton);
      newWinButton.addActionListener(this);
      toggleButton.addActionListener(this);
      mainwin = JSObject.getWindow(this);
   }

   public void start() {
      mainwin.eval("document.indicator.running.value = 'Yes'");
   }

   public void actionPerformed(ActionEvent evt) {
      Button source = (Button)evt.getSource();
      if (source == newWinButton) {
         doNewWindow();
      } else if (source == toggleButton) {
         toggleColor();
      }
   }

   void doNewWindow() {
      subwin = (JSObject) mainwin.eval("window.open('','fromApplet','HEIGHT=200,WIDTH=200')");
      subwin.eval("document.write('<html><body bgcolor=white>Howdy from the applet!</body></html>')");
      subwin.eval("document.close()");
   }

   void toggleColor() {
      if (subwin != null) {
         JSObject arg[] = {subwin};
         mainwin.call("toggleSubWindowColor", arg);
      }
   }
}
